package ola.com.booking.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ola.com.booking.ConectionManager;
import ola.com.booking.dao.RideDao;
import ola.com.booking.model.Ride;

public class RideDaoImpl implements RideDao {
	Connection conn = ConectionManager.getConnection();

	@Override
	public void saveRide(Ride ride) {
		try {
			PreparedStatement stmt = conn
					.prepareStatement("insert into ride (rideId, userId, routeId, date) values (NULL,?,?,?)");

			stmt.setInt(1, ride.getUserId());
			stmt.setInt(2, ride.getRouteId());
			stmt.setString(3, ride.getDateTime().toString());
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	private static java.sql.Date getCurrentDate() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Date(today.getTime());
	}

	@Override
	public Ride getRides() {
		Ride ride = new Ride();
		try {
			ResultSet result = conn.createStatement().executeQuery("select * from ride");
			while (result.next()) {

				ride.setRideId(result.getInt("rideId"));
				ride.setUserId(result.getInt("userId"));
				ride.setRouteId(result.getInt("routeId"));
				ride.setDateTime(result.getDate("date"));

			}
			return ride;

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return null;
	}

}
