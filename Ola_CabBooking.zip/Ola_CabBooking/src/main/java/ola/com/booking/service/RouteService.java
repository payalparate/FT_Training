package ola.com.booking.service;

import java.util.List;

import ola.com.booking.model.Route;

public interface RouteService {

	//create a class containing all route class members + userId
	public List<Route> getRoutes();
}
