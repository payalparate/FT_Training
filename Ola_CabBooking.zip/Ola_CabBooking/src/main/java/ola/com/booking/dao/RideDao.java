package ola.com.booking.dao;

import ola.com.booking.model.Ride;

public interface RideDao {
	void saveRide(Ride ride);

	public Ride getRides();
}
