package ola.com.booking.service.impl;

import ola.com.booking.dao.RideDao;
import ola.com.booking.dao.impl.RideDaoImpl;
import ola.com.booking.model.Ride;
import ola.com.booking.service.RideService;

public class RideServiceImpl implements RideService {

	@Override
	public void saveRide(Ride ride) {

		RideDao rideDao = new RideDaoImpl();
		// ride.setRideId(RideHelper.getIncrement());
		rideDao.saveRide(ride);

	}

	@Override
	public Ride getRides() {
		RideDao rideDao1 = new RideDaoImpl();
		return rideDao1.getRides();

	}

}
