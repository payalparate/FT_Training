package ola.com.booking;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ola.com.booking.model.Ride;
import ola.com.booking.service.RideService;
import ola.com.booking.service.impl.RideServiceImpl;

@WebServlet("/ride")
public class RideServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	RideService rideService = new RideServiceImpl();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if (req.getParameter("action").equals("rider")) {
			Ride ride = new Ride();

			java.util.Date utilDate = new java.util.Date();
			java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

			ride.setUserId(Integer.parseInt(req.getParameter("userId")));
			ride.setRouteId(Integer.parseInt(req.getParameter("routeId")));
			System.out.println("Route Id : " + ride.getRouteId());
			ride.setDateTime(sqlDate);

			rideService.saveRide(ride);
			req.setAttribute("ride", rideService.getRides()); // all rout info + userId
			RequestDispatcher rd = req.getRequestDispatcher("/WEB-INF/views/ride.jsp");
			rd.forward(req, resp);
		}
	}
}
