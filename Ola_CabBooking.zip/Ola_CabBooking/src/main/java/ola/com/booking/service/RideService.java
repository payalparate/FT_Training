package ola.com.booking.service;

import java.util.List;

import ola.com.booking.model.Ride;



public interface RideService {
	public void saveRide(Ride ride);
	public Ride getRides();
}
