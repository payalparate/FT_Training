package ola.com.booking.dao;

import java.util.List;

import ola.com.booking.model.Route;

public interface RouteDao {

	public List<Route> getRoutes();
}
