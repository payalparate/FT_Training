package analyses;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountOfWordsInString {

	public static void main(String[] args) {
		String str = "Welcome to my place my place Welcome you";
		List<String> list = Arrays.asList(str.split(" "));
		Map<String, Long> map = list.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(map);

	}

}
