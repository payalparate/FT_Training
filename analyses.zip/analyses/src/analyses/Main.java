package analyses;

public class Main
{
  
	
	    public static void main(String[] args) {
	    	String s = "Ashu";
	    	String s1 = new String("Ashu");    	
	    }
}
