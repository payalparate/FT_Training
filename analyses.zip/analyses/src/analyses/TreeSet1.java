package analyses;

import java.util.*; 

public class TreeSet1
{ 
    public static void main(String[] args) 
    { 
        TreeSet<String> treeSet = new TreeSet<>(); 
  
        /*treeSet.add("Geeks"); 
        treeSet.add("for"); 
        treeSet.add("Geeks"); 
        treeSet.add("GeeksforGeeks"); */
  
        treeSet.add("123");
        treeSet.add("ABC");
        treeSet.add("12abc");
        treeSet.add("abc12");
        treeSet.add("12ABC");
        treeSet.add("ABC12");
        for (String temp : treeSet) 
            System.out.printf(temp + " "); 
  
        System.out.println("\n"); 
    } 
} 

/*public static void main(String[] args) {
    boolean bool1 = true;
    boolean bool2 = !true ;//false;
    System.out.println(bool2);//false
    boolean bool3 = bool1 | bool1;//true
    System.out.println(bool3);//true
    boolean bool4 = bool1 & bool2;
    System.out.println(bool4);//false
    boolean bool5 = bool4 ? bool3 : bool2;//false
    System.out.println(bool4 + " " + bool5);false false

}*/
