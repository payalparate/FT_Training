package analyses;

public class AssertionExample {
	static void test() throws Error
	{
		if(true)
		
			throw new AssertionError();
			System.out.println("Hi");
		
	}
	public static void main(String[] args) {
		
          try
          {
        	  test();
          }
          catch(Exception e)
          {
        	  System.out.println("Hello");
          }
          System.out.println("BYE");
	}

}
