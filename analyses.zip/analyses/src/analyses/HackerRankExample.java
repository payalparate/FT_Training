package analyses;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class HackerRankExample {

	/*
	 * public static String[] missingWords(String s, String t) { String[] subt =
	 * t.split(" "); for (int i = 0; i < subt.length; i++) { s =
	 * s.replaceAll(subt[i] + " ", ""); } return s.split(" "); }
	 */
	public String[] uncommonFromSentences(String A, String B) {
        Set<String> distinct = new HashSet<>(), com = new HashSet<>();
        for (String s : (A + " " + B).split("\\s")) {
            if (com.contains(s) || !distinct.add(s)) { distinct.remove(s); com.add(s); }
        }
        return distinct.toArray(new String[0]);
    }
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		HackerRankExample hr= new HackerRankExample();
		System.out.println("Enter 2 strings");
		String s = "I am using HackerRank to improve programming to I";
		String t = "am am HackerRank to improve to";
		System.out.println(hr.uncommonFromSentences(s, t));

	}
}
