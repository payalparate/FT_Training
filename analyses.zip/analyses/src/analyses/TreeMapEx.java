package analyses;

import java.util.TreeMap;

public class TreeMapEx {
	public static void main(String args[]){
        TreeMap<Integer,String> map=new TreeMap<Integer,String>();  
        //no duplication
        //ascending
        //duplicate values are allowed if keys are different
           map.put(109,"Amit");   
           map.put(102,"Ravi");   
           map.put(101,"Vijay");   
           map.put(104,"Rahul");   
           map.put(104,"ga");
           map.put(105,"ga");
           map.put(1,null);
          map.put(1,"av");  //null values are allowed
          // map.put(null,"null");// index can't be null
         System.out.println(map);
      }
}
