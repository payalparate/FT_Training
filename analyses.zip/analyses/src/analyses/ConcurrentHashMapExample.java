package analyses;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
public class ConcurrentHashMapExample {
	public static void main(String[] args) {

		Map<Integer, String> myMap = new ConcurrentHashMap<Integer, String>();
		myMap.put(1, "1");
		myMap.put(2, "2");
		myMap.put(3, "3");

		Iterator<Integer> t1= myMap.keySet().iterator();
		
		while(t1.hasNext()) {
			int key = t1.next();
			if(key==1)
			{
				myMap.remove(2);
			}
			else
				myMap.put(4, "4");
		}

		System.out.println("Map Size:" + myMap);
	}
}
