package analyses;
abstract class Abc
{
	abstract void display();
	void show()
	{
		
	}
}
class Test extends Abc{
	int i;

	Test(int i) {
		this.i = i;
	}

	public int hashCode() {
		System.out.println("Hello123");
		return i;
	}

	public String toString() {
		return i + " Hi";
	}

	public static void main(String[] args) {
		Test t1 = new Test(10);
		Test t2 = new Test(100);
		System.out.println(t1);
		System.out.println(t2);
	}

	@Override
	void display() {
		// TODO Auto-generated method stub
		
	}
}
