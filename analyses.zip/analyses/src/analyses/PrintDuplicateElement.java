package analyses;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PrintDuplicateElement {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,67,1, 90,23,90,33,67);
		Set<Integer> set = new HashSet<>();
		list.stream().filter(x -> !set.add(x)).collect(Collectors.toSet()).forEach(System.out::println);
       
	}

}
