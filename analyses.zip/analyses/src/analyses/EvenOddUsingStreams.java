package analyses;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class EvenOddUsingStreams {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1,7,2,6,4,8,5);
		list.sort(Comparator.naturalOrder());
		list.stream().filter(x -> x%2==0).forEach(x -> System.out.println(x));

	}

}
