package analyses;

public class Book
{
	public static void main(String[] args) {
		
		StringBuffer s= new StringBuffer();
			s.append("abgjdbj ghkfjdkb");
			System.out.println(s.capacity());
        System.out.println(tryCatchFinally());
    }

 

    static String tryCatchFinally() {
        try {
            throw new Exception();
//            return "try";
        } catch (Exception e) {
            return "catch";
        } finally {
            return "returnning finally";
        }
    }
}