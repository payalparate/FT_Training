package analyses;

import java.util.Scanner;
import java.util.Stack;

public class DecimalBinaryExample {
	public static void main(String a[]) {
		// Predefined method
		System.out.println("Binary representation of 124: ");
		System.out.println(Integer.toBinaryString(124));
		System.out.println("\nBinary representation of 45: ");
		System.out.println(Integer.toBinaryString(45));
		System.out.println("\nBinary representation of 999: ");
		System.out.println(Integer.toBinaryString(999));

		Scanner in = new Scanner(System.in);

		// Create Stack object
		Stack<Integer> stack = new Stack<Integer>();

		// User input
		System.out.println("Enter decimal number: ");
		int num = in.nextInt();

		while (num != 0) {
			int d = num % 2;
			stack.push(d);
			num /= 2;
		}

		System.out.print("\nBinary representation is:");
		while (!(stack.isEmpty())) {
			System.out.print(stack.pop());
		}
		System.out.println();
	}
}

//
//1st way
/*if (b == 0)
  return a;
return gcd(b, a % b);*/
	
	//2nd way
	/*if(a==b)  //98!=56--42!=56
		return a;
	else if(a>b)//98>56 --->no--->
		return 	gcd(a-b,b); //42,56
	else                   //42<56
		return gcd(b,b-a);// 56,14
	*/
	
	//3rd way