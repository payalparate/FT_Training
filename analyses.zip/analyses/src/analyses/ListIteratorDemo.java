package analyses;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.ListIterator;
import java.util.Set;

public class ListIteratorDemo 
{
	
  public static void main(String[] args) 
  {
	  
    //List<String> names = new CopyOnWriteArrayList();
	  Set names = new LinkedHashSet();
    names.add("Rams");
    names.add("Posa");
    names.add("Chinni");
       // Collections.reverse(names);
    // Getting ListIterator
    Iterator<String> namesIterator = names.iterator();
     
    while(namesIterator.hasNext()){
       System.out.println(namesIterator.next()); 
       namesIterator.remove();           
    } 
    System.out.println(names);
 /* for(String name: names){
       System.out.println(name);            
    } */  
  }
}