package analyses;
interface fun
{
	public abstract int multiply(int a, int b);
}
public class FunctionalInterface{

	public static void main(String[] args) {
		fun f = (a,b) -> a*b;
		System.out.println(f.multiply(2,3));

	}

	

}
