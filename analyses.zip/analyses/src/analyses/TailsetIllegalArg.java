package analyses;

import java.util.HashMap;
import java.util.Map;
import java.util.NavigableSet;
import java.util.TreeSet;

public class TailsetIllegalArg {

    public static void main(String[] args) 
    {    
    	Map m= new HashMap<>();
    	m.get(0).hashCode();
    	NavigableSet obj=new TreeSet();   
    	NavigableSet obj1=new TreeSet();     
    	obj.add(4);     
    	obj.add(6);    
    	obj.add(9);     
    	obj.add(2);      
    	System.out.println(obj);  
    	obj1=(NavigableSet) obj.tailSet(2);
    			
    	obj1.add(3);
    	System.out.println(obj1);  

/*1110110
0001111
=
0000110

1110011
0001111=*/
    	}

}