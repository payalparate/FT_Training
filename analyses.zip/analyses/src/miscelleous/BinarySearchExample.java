package miscelleous;

import java.util.Arrays;

public class BinarySearchExample {

	public static void binarySearch(int arr[], int first, int last, int key) {
		int mid = (first + last) / 2;    // first=0, mid=2, last=4;
		while (first <= last) {
			if (arr[mid] < key) { 
				first = mid + 1; 
			} else if (arr[mid] == key) { 
				System.out.println("\nElement is found at index: " + mid);
				break;
			} else {
				last = mid - 1; 
			}
			mid = (first + last) / 2; 
		}
		if (first > last) {
			System.out.println("\nElement is not found!");
		}
	}

	public static void main(String args[]) {
		int arr[] = { 10, 20, 30, 40, 50 };
		int key = 20;
		int last = arr.length - 1; // index 4
		 System.out.println("The input Array : " + Arrays.toString(arr));
		 System.out.println("\nThe key to be searched:" + key);
		binarySearch(arr, 0, last, key);
		
		
		
	}
}
