package miscelleous;

import java.util.Set;
import java.util.TreeSet;

public class AbsDistinctCaterpiller {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static int solution(int[] A) {
		Set s = new TreeSet();
		for (int i = 0; i < A.length; i++)
			s.add(Math.abs(A[i]));
		return s.size();
	}

	public static void main(String[] args) {
		int[] A = { -5, -3, 1, 0, 3, 6 };
		System.out.println(solution(A));

	}

}
