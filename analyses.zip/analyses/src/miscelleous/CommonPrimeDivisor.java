package miscelleous;

import java.util.LinkedHashSet;
import java.util.Set;

public class CommonPrimeDivisor {
	public static int solution(int[] A, int[] B) {
		int Z = A.length;
		int result = 0;

		for (int i = 0; i < Z; i++) {
			if (isSameDivisors(A[i], B[i])) {
				result++;
			}
		}
		return result;
	}

	private static boolean isSameDivisors(int n, int k) {
		Set<Integer> set = new LinkedHashSet<Integer>();
		Set<Integer> set1 = new LinkedHashSet<Integer>();

		for (int i = 2; i <= n; i++) {
			while (n % i == 0) {
				set.add(i);
				n = n / i;
			}
		}

		for (int i = 2; i <= k; i++) {
			while (k % i == 0) {
				set1.add(i);
				k = k / i;
			}
		}
		return set.equals(set1) ? true : false;
	}

	public static void main(String[] args) {
		int A[] = new int[] { 15, 10, 3 };
		int B[] = new int[] { 75, 30, 5 };
		System.out.println(solution(A, B));
	}
}
