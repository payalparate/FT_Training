package miscelleous;

import java.util.Arrays;

public class BinarySearchExample3 {
	 public static int binarySearch(int arr[], int first, int last, int key){  
	        if (last>=first){  
	            int mid = first + (last - first)/2;  
	            if (arr[mid] == key){  
	            return mid;  
	            }  
	            if (arr[mid] > key){  
	            return binarySearch(arr, first, mid-1, key);//search in left subarray  
	            }else{  
	            return binarySearch(arr, mid+1, last, key);//search in right subarray  
	            }  
	        }  
	        return -1;  
	    }  
	    public static void main(String args[]){  
	        int arr[] = {10,20,30,40,50};  
	        int key = 40;  
	        int last=arr.length-1;  
	        System.out.println("The input Array : " + Arrays.toString(arr));
			System.out.println("\nThe key to be searched:" + key);
	        int result = binarySearch(arr,0,last,key);  
	        if (result == -1)  
	            System.out.println("\nElement is not found!");  
	        else  
	            System.out.println("\nElement is found at index: "+result);  
	    }  
}
