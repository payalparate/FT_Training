package miscelleous;

public class KadaneAlgorithm {
	/*public static int Kadanes(int[] array){
	    int n = array.length;
	    int[] dp = new int[n];

	    //base condition
	    dp[0] = array[0];

	    int max = Integer.MIN_VALUE;
	    for(int i = 1; i < n; i++){
	        dp[i] = Math.max(dp[i - 1], 0) + array[i];
	        max = Math.max(max, dp[i]);
	    }
	    return max;
	} */
	public static int solution(int A[])
	{
		int max=A[0];
		int maxsofar=A[0];
		for (int i = 0; i < A.length; i++) {
			maxsofar=Math.max(A[i], (A[i]+maxsofar));
					if(maxsofar>=max)
					{
						max=maxsofar;
					}
		}
		return max;
		
	}
	public static void main(String[] args) {
		int arr[]= {3,2,-6,4,0};
		System.out.println(solution(arr));

	}

}
