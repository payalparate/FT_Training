package miscelleous;
import java.util.*;

class CaterpillerMethod {
	    public static int solution(int[] arr, int target) {
	        int first = 0;
	        int last = arr.length - 1;


	        while (first < last) {
	            if (arr[first] + arr[last] == target) {
	                return 1;
	            } else if (arr[first] + arr[last] < target) {
	            	first++;
	            } else {
	            	last--;
	            }
	        }
	        return target;
	    }

	    public static void main(String[] args) {
	        int[] arr = { 2, 7, 11, 15 };
	        int target = 9;
	        System.out.println(solution(arr, target));

	    }
	}
	 

