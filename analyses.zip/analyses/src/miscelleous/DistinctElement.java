package miscelleous;

public class DistinctElement {
	static int countDistinctValues(int arr[], int n) 
	{ 
	    int count = 1; 
      for (int i = 1; i < n; i++)  
	    { 
	        int j = 0; 
	        for (j = 0; j < i; j++) 
	            if (arr[i] == arr[j]) 
	                break; 
	        if (i == j) 
	        	count++; 
	    } 
	    return count; 
	} 

	public static void main(String[] args) 
	{ 
	    int arr[] = { 2,1,1,2,3,1}; 
	    int n = arr.length; 
	    System.out.println("No. of distinct elements are : "+countDistinctValues(arr, n)); 
	} 
}
