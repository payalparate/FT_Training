package miscelleous;

import java.util.Arrays;

public class BinarySerachExample2 {
	public static void main(String args[]){  
        int intArray[] = {10,30,20,40,60,50,70,80,90};
        System.out.println("The input Array : " + Arrays.toString(intArray));
        Arrays.sort(intArray);
        System.out.println("After sorting "+Arrays.toString(intArray));
        int key = 50;  
        System.out.println("\nThe key to be searched:" + key);      
        int result = Arrays.binarySearch(intArray,key);  
        if (result < 0)  
            System.out.println("\nKey is not found in the array!");  
        else 
            System.out.println("\nKey is found at index: "+result + " in the array.");  
    }  
}
