package miscelleous;

public class FlipBitDemo {
public static void main(String[] args) {
    String target="01011";
    System.out.println(minFlips(target));
    }

private static int minFlips(String target) {
    char curr='1';
    int count=0;
    for(int i=0;i<target.length();i++)
    {
        if(target.charAt(i)==curr)  
        {
            count++;
            curr=(char)(48 +(curr +1)%2);  
        }
    }
    return count;
}
}