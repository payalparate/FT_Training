package miscelleous;

import java.util.Scanner;

public class CondensedList {
	private Node head;	 

    public boolean isEmpty() {
        return (head == null);
    }


    public boolean checkList(int data) {
        boolean flag = true;
        System.out.println("checking list element");
        Node firstnode = head;
        while (firstnode != null) {
            int d = firstnode.data;
            firstnode = firstnode.next;
            if (d == data) {
                flag = false;
            }
        }
        return flag;
    }

 
    public void insertLast(int data) {
       Node current = head;
        if (head == null) {
            Node newNode = new Node();
            newNode.data = data;
            newNode.next = null;
            head = newNode;
        } else {

            while (current.next != null) {
                current = current.next; // we'll loop until current.next is null
            }

            if (checkList(data)) {

                Node newNode = new Node();
                newNode.data = data;
              current.next = newNode;
            }
        }
    }

    public void printLinkedList() {
        System.out.println("Printing LinkedList (head --> last) ");
        Node current = head;
        while (current != null) {
            current.displayData();
            current = current.next;
        }
        // System.out.println();
    }

	public static void main(String[] args) {
		CondensedList myLinkedlist = new CondensedList();
	        Scanner sc = new Scanner(System.in);
	        int size = sc.nextInt();
	        for (int i = 0; i < size; i++) {
 
	            myLinkedlist.insertLast(sc.nextInt()); 
	        }
	        myLinkedlist.printLinkedList();
	     
	    }
	}

