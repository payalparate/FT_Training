package miscelleous;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class UncommonWordsExample {
	public List<String> missingWords(String s, String t) {
		List<String> list = new ArrayList<>(Arrays.asList(s.split(" ")));

		for (String str : Arrays.asList(t.split(" "))) {
			if (list.contains(str)) {
				list.remove(str);
			} else
				list.add(str);
		}
		return list;
	}

	public static void main(String[] args) {
		UncommonWordsExample example = new UncommonWordsExample();
		String s = "I like cheese";
		String t = "like";
		List<String> list = example.missingWords(s, t);
		for (String words : list) {
			System.out.println(words);
		}

	}

}