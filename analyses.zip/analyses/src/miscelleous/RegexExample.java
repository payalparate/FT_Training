package miscelleous;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexExample {

	public static void main(String[] args) {
		
		        String input1 = "123457";
		        String input2 = "qwerty";
		        String input3 = "QWERTY";
		        String input4 = "*@$$$$";
		        System.out.println(Pattern.matches("^[0-9]{6}", input1));
		        System.out.println(Pattern.matches("^[a-z]{6}", input2));
		        System.out.println(Pattern.matches("^[A-Z]{6}", input3));
		        System.out.println(Pattern.matches("^[@$*]{6}", input4));


		        Pattern p = Pattern.compile("^[@$*]{6}");
		        Matcher matcher = p.matcher(input4);
		        System.out.println(matcher.matches());


		        boolean matches = Pattern.compile("^[a-zA-Z]\\d$").matcher("a1").matches();
		        System.out.println(matches);


		        String password = "Ankit@465";
		        System.out.println(Pattern.matches("[(A-Z){1}[A-Za-z@]{5}[\\d]{3}]", password));
		        System.out.println(Pattern.matches("^[A-Z]{1}[\\d]{3}[A-Za-z@]{5,10}", password));


		        // length 8 having a-z A-Z 0-9
		        String password1 = "qe@r19oqqwbvsldv";


		        String reg = "[0-9{2}a-zA-Z@]{8,16}";
		        System.out.println(Pattern.matches(reg, password1));


		        String password2 = "qe@r19oqqwbvsldv";
		        String reg2 = "[0-9{2}a-zA-Z@]{8,16}";
		        System.out.println(Pattern.matches(reg2, password2));


		    }
		}
