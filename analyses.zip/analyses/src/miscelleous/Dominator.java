package miscelleous;

public class Dominator {
	static int solution(int A[], int N) {
		int candidate = 0;
		int count = 0;

		for (int i = 0; i < N; i++) {
			if (count == 0)
				candidate = i;
			if (A[i] == A[candidate])
				count++;

			else
				count--;
		}

		count = 0;
		for (int j = 0; j < N; j++)
			if (A[j] == A[candidate])
				count++;

		if (count <= N / 2)
			return -1;
		return count;
	}

	public static void main(String[] args) {
		int[] A = { 3, 4, 3, 2, 3, -1, 3, 3 };
		int N = A.length;
		System.out.println(solution(A, N));
	}
}
