package miscelleous;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DistanceMetrics {
	static List<Long> minimumDistance(List<Integer> arr) {
		List<Long> list = new ArrayList<>();
		Long l = 0l;
		int[] output = new int[arr.size()];
		for (int i = 0; i < arr.size(); i++) {

			for (int j = 0; j < arr.size(); j++) {

				if (arr.get(i) == arr.get(j)) {
					output[i] += Long.valueOf(Math.abs((i - j)));
				}

			}
			l = Long.valueOf(output[i]);
			list.add(l);
		}

		return list;
	}

	public static void main(String[] args) {
		List<Integer> arr = Arrays.asList(1, 2, 1, 1, 2, 3);
		System.out.println(minimumDistance(arr));
	}
}
