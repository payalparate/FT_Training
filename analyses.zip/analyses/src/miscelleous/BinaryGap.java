package miscelleous;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BinaryGap {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the decimal number");
		String binaryString = Integer.toBinaryString(sc.nextInt());
        System.out.println(binaryString);
		int longestBinaryGap = 0;
		List<Integer> ones = new ArrayList<>();
		for (int i = 0; i < binaryString.length(); i++) {
			if (binaryString.charAt(i) == '0') {
				continue;
			}
			ones.add(i);
		}
		for (int i = 0; i < ones.size() - 1; i++) {
			int indicesDiff = ones.get(i + 1) - ones.get(i) - 1;
			longestBinaryGap = Math.max(longestBinaryGap, indicesDiff);
		}
		System.out.println(longestBinaryGap);
		sc.close();
	}
}
