package miscelleous;

import java.util.Arrays;

public class TicketSubsequence {

	public static int subsequence(int[] A) {
		Arrays.sort(A);
		int temp = 0, count = 0;
		for (int i = 0; i < A.length - 1; i++) {
			if ((Math.abs(A[i + 1] - A[i]) == 0) || (Math.abs(A[i + 1] - A[i]) == 1)) {
				temp++;

			} else {
				count++;
			}
		}
		int max = Math.max(temp, count);
		return max;
	}

	public static void main(String[] args) {
		int[] A = { 8, 5, 4, 8, 4 };
		System.out.println(subsequence(A));
	}

}
