package miscelleous;

import java.util.Stack;
public class StackExample {
	static int solution(String S) {
        Stack<Character> stack = new Stack<Character>();
        for (int i = 0; i < S.length(); i++) {
            char pointer = S.charAt(i);
            if (pointer == '[' || pointer == '{' || pointer == '(') {
                stack.push(pointer);
            }
            if(stack.isEmpty())return 0;
            switch (pointer) {
            case ')':
                if (stack.peek() == '{' || stack.peek() == '[')
                    return 0;
                else
                    stack.pop();
                break;
            case '}':
                if (stack.peek() == '(' || stack.peek() == '[')
                    return 0;
                else
                    stack.pop();
                break;
            case ']':
                if (stack.peek() == '{' || stack.peek() == '(')
                    return 0;
                else
                    stack.pop();
                break;
            }
        }
        return stack.isEmpty()?1:0;
    }
   public static void main(String[] args) {
	  String s="{[()()]}";
	   System.out.println(solution(s));
}	
}

