package miscelleous;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class CountingBits {
	public static int[] getOneBit(int num) {
        String bit = Integer.toBinaryString(num);
        List<Integer> list = new LinkedList();
        int[] arr;
        int count = 0;
        int index = 0;
        String[] bits = bit.split("");
        for (String string : bits) {
              index++;
              if (1 == Integer.parseInt(string)) {
                    count++;
                    list.add(index);
              }
        }
        list.add(0, count);
        arr = new int [list.size()];
         for(int i = 0;i < arr.length;i++)
                  arr[i] = list.get(i);

        return arr;
  }
        public static void main(String[] args) {
	       System.out.println(Arrays.toString(getOneBit(37)));
    }
}
