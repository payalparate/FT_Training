package miscelleous;

import java.util.Stack;

public class StackPatternExample {
	static int solution(String S) {
		Stack charStack = new Stack();
		for (int i = 0; i < S.length(); i++) {
			char currentChar = S.charAt(i);
			if (isOpeningBracket(currentChar)) {
				charStack.push(currentChar);
			} else {
				if (charStack.size() == 0) {
					return 0;
				}
				char poppedChar = (char) charStack.pop();
				if (isBracketMatch(poppedChar, currentChar)) {
					continue;
				} else
					return 0;
			}
		}
		if (charStack.isEmpty())
			return 1;

		return 0;
	}

	static boolean isOpeningBracket(char pC) {
		if (pC == '[' || pC == '(' || pC == '{') {
			return true;
		}
		return false;
	}

	static boolean isBracketMatch(char pC1, char pC2) {
		if (pC1 == '[' && pC2 == ']')
			return true;
		if (pC1 == '(' && pC2 == ')')
			return true;
		if (pC1 == '{' && pC2 == '}')
			return true;
		return false;
	}

	public static void main(String[] args) {
		System.out.println(solution("{[()()]}"));
	}
}
