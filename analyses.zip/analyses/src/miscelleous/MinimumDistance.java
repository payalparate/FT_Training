package miscelleous;

import java.util.HashMap;

public class MinimumDistance {

	public static int solution(int[] A)
	{
		HashMap<Integer,Integer> hmap= new HashMap();
		int minDistance=Integer.MAX_VALUE,preIndex=0,currentIndex=0;
		
		for (int i = 0; i < A.length; i++) {
			if(hmap.containsKey(A[i]))
			{
				currentIndex=1;
				preIndex=hmap.get(A[i]);
				minDistance=Math.min((currentIndex-preIndex), minDistance);
			}
			hmap.put(A[i], i);
		}
		return(minDistance==Integer.MAX_VALUE ?-1: minDistance);
	}
	public static void main(String[] args) {
		int[]A= {1,2,1,1,2,3};
		System.out.println("Minimum distance is : "+solution(A));

	}

}
