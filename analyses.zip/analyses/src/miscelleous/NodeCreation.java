package miscelleous;
class Node {
	int data;
	Node next;
	void displayData() {
		System.out.println("[" + data + "]");
	}
}

class SinglyLinkedList1 {
	private Node head;

	public void insertAfter(int data)// 7
	{
		Node current = head;// 5,null
		while (current.next != null) {
			current = current.next;
		}
		Node newNode = new Node();
		newNode.data = data;// 6
		current.next = newNode;
	}

	public void insertFirst(int data) {
		Node newNode = new Node();
		newNode.data = data;// 7
		newNode.next = head;
		head = newNode;
	}

	public void deleteNode(Node after) {
		Node temp = head;
		while (temp.next != null && temp.data != after.data) {
			temp = temp.next;
		}
		if (temp.next != null) {
			temp.next = temp.next.next;
		}
	}
	public void printList() {
		System.out.println("Priniting List Elements");
		Node firstnode = head;
		while (firstnode != null) {
			firstnode.displayData();
			firstnode = firstnode.next;
		}
	}
}
class NodeCreation {
	public static void main(String args[]) {
		SinglyLinkedList1 sll = new SinglyLinkedList1();
		sll.insertFirst(100);// 5
		sll.printList();
		sll.insertAfter(105);// 6
		sll.printList();
		sll.insertAfter(50);// 7
		sll.printList();
		Node node = new Node();
		node.data = 100;
		sll.deleteNode(node);
		sll.printList();
	}
}
