package miscelleous;

public class ChocolatesByNumbers {
	public static int solution(int N, int M)
	{
	    int count = 1;
	    int start = 0;
	    int value;
	    while ((start + M) % N != 0)
	    {
	        value = (start + M) % N;
	        start = value;
	        count++;
	    }
	    return count;
	}
	public static void main(String args[]) {
		int N = 10;
		int M= 4;
		System.out.println(solution(N,M));
	}

}
