package miscelleous;

import java.util.Arrays;

public class MinAbsSumOfTwo {
	public static int solution(int[] A) {
		int len = A.length;
		Arrays.sort(A);
		int begin = 0, end = len - 1;
		int sum = Math.abs(A[begin] + A[end]);
		while (begin < end) {
			int newSum = 0;
			if (Math.abs(A[begin + 1] + A[end]) < Math.abs(A[begin] + A[end - 1])) {
				newSum = Math.abs(A[begin + 1] + A[end]);
				begin++;
			} else {
				newSum = Math.abs(A[begin] + A[end - 1]);
				end--;
			}
			sum = Math.min(sum, newSum);
		}
		return sum;
	}

	public static void main(String[] args) {
		int[] A = { 1, 4, -3 };
		System.out.println(solution(A));
	}

}
