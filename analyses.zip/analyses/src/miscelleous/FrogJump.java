package miscelleous;

public class FrogJump {
	static int solution(int X, int Y, int D) {
		int distance = Y - X;
		int jumpReq = distance / D;
		if (distance % D != 0) {
			jumpReq++;
		}
		return jumpReq;
	}

	public static void main(String[] args) {
		System.out.println("Number of jumps required : " + solution(10, 85, 30));
	}
}
